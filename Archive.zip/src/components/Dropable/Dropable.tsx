import { useState, useRef } from "react";
import { SideBarItem, sidebarItems } from "../../constants";
import Draggable from "../Draggable/Draggable";
import "./Dropable.css";

type DroppedItem = {
  id: number;
  shape: string;
  x: number;
  y: number;
};

const Dropable = () => {
  const [activeItem, setActiveItem] = useState<SideBarItem | null>(null);
  const [items, setItems] = useState<DroppedItem[]>([]);
  const dropAreaRef = useRef<HTMLDivElement | null>(null);

  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    if (activeItem && dropAreaRef.current) {
      const dropAreaRect = dropAreaRef.current.getBoundingClientRect();

      // Calculate position relative to the drop area
      const x = event.clientX - dropAreaRect.left;
      const y = event.clientY - dropAreaRect.top;

      setItems((prev) => [
        ...prev,
        {
          id: prev.length,
          shape: activeItem.shape,
          x,
          y,
        },
      ]);
      setActiveItem(null);
    }
  };

  const handleDrag = (event: React.MouseEvent, id: number) => {
    const dropAreaRect = dropAreaRef.current?.getBoundingClientRect();
    if (!dropAreaRect) return;

    const { clientX, clientY } = event;

    setItems((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              x: clientX - dropAreaRect.left,
              y: clientY - dropAreaRect.top,
            }
          : item
      )
    );
  };

  return (
    <div className="wrapper">
      {/* Sidebar */}
      <div className="sidebar">
        {sidebarItems.map((item, index) => (
          <Draggable
            onDragStart={() => setActiveItem(item)}
            onDragEnd={() => setActiveItem(null)}
            key={index}
          >
            {item.shape}
          </Draggable>
        ))}
      </div>

      {/* Drop Area */}
      <div
        ref={dropAreaRef}
        onDrop={handleDrop}
        onDragOver={(e) => e.preventDefault()}
        className="drop-area"
      >
        <svg className="lines" width="100%" height="100%">
          {items.map((item, index) => {
            if (index === 0) return null;

            const prevItem = items[index - 1];
            return (
              <line
                key={`line-${prevItem.id}-${item.id}`}
                x1={prevItem.x}
                y1={prevItem.y}
                x2={item.x}
                y2={item.y}
                stroke="black"
                strokeWidth="2"
              />
            );
          })}
        </svg>

        {/* Render Dropped Items */}
        {items.map((item) => (
          <div
            key={item.id}
            className="dropped-item"
            style={{ left: item.x, top: item.y }}
            draggable
            onDragStart={(e) => e.preventDefault()} // Prevent default browser drag
            onMouseDown={() => {
              const handleMouseMove = (moveEvent: MouseEvent) => {
                handleDrag(moveEvent as unknown as React.MouseEvent, item.id);
              };

              const handleMouseUp = () => {
                document.removeEventListener("mousemove", handleMouseMove);
                document.removeEventListener("mouseup", handleMouseUp);
              };

              document.addEventListener("mousemove", handleMouseMove);
              document.addEventListener("mouseup", handleMouseUp);
            }}
          >
            {item.shape}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dropable;
