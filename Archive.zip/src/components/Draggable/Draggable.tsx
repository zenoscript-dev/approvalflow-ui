import { ReactNode } from "react";

const Draggable = ({
  children,
  onDragStart,
  onDragEnd,
}: {
  children: ReactNode;
  onDragStart: () => void;
  onDragEnd: () => void;
}) => {
  return (
    <div
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      draggable
    >
      {children}
    </div>
  );
};

export default Draggable;
