export type SideBarItem = {
    id: number,
    name: string,
    shape: string
}

export const sidebarItems:SideBarItem[] = [
    {
    id: 1,
    name: 'start',
    shape: '🟢'
},
    {
    id: 2,
    name: 'task',
    shape: '🔷'
},
    {
    id: 3,
    name: 'end',
    shape: '🔴'
},
]