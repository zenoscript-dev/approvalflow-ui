import "./App.css";
import Dropable from "./components/Dropable/Dropable";

function App() {
  return (
    <>
      <Dropable />
    </>
  );
}

export default App;
